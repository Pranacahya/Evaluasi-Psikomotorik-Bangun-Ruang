TouchEverything
===============
Small experiment with leap motion.
We're trying to use sensor as touch substitute and checked this with different surfaces and subjects.
##Main Project Video
https://vimeo.com/111624691

![tag](http://artcr.ru/yuri/github/leappreview.png)

##Publications
* Official facebook Leap Motion page
https://www.facebook.com/LeapMotion/posts/670952983021570

* Gizmodo
http://gizmodo.com/literally-anything-is-a-touchscreen-with-this-leap-moti-1658789874

##Short Description
Our corporative blog [in russian]  
http://lab.familyagency.ru/post/99400233352/touch-everything

